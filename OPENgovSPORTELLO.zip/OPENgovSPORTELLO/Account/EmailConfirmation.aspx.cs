﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace OPENgovSPORTELLO.Account
{
    /// <summary>
    /// Pagina di avviso conferma registrazione
    /// </summary>
    /// <remarks>In ottemperanza alle linee guida di sviluppo 1.0</remarks>
    public partial class EmailConfirmation : GeneralPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}