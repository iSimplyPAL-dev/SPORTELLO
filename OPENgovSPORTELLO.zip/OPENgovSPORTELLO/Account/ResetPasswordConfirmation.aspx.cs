﻿using System.Web.UI;

namespace OPENgovSPORTELLO.Account
{
    /// <summary>
    /// Pagina di conferma cambio password
    /// </summary>
    /// <remarks>In ottemperanza alle linee guida di sviluppo 1.0</remarks>
    public partial class ResetPasswordConfirmation : GeneralPage
    {
    }
}