﻿using log4net;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.Owin;
using OPENgovSPORTELLO.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
//...
using System.IO;
using System.Xml.Serialization;
using System.Xml;

namespace OPENgovSPORTELLO.SPID
{
    /// <summary>
    /// 
    /// </summary>
    public partial class POST : GeneralPage
    {
        private static readonly ILog Log = LogManager.GetLogger(typeof(POST));
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            string mySAMLResponse,spidCode, fiscalNumber, ivaCode, email;
            mySAMLResponse=spidCode = fiscalNumber = ivaCode = email = string.Empty;
            try
            {
                if (Request["SAMLResponse"] != null)
                    mySAMLResponse = System.Text.Encoding.UTF8.GetString(Convert.FromBase64String(Request["SAMLResponse"]));

                if (mySAMLResponse != string.Empty)
                {
                    /*using (MemoryStream ms = new MemoryStream(System.Text.Encoding.UTF8.GetBytes(mySAMLResponse)))
                    {
                        XmlSerializer xmlSerializer = new XmlSerializer(typeof(AttributeStatement));
                        AttributeStatement response = (AttributeStatement)xmlSerializer.Deserialize(ms);
                        email = response.Attribute.FirstOrDefault(x => x.Name == "email").AttributeValue?.TrimEnd();
                    }*/

                    var reader = XmlReader.Create(new MemoryStream(Convert.FromBase64String(Request["SAMLResponse"])));
                    var serializer = new XmlSerializer(typeof(XmlElement));
                    var samlResponseElement = (XmlElement)serializer.Deserialize(reader);

                    foreach(XmlNode myChildRespose in samlResponseElement.ChildNodes)
                    {
                        if (myChildRespose.Name == "saml:Assertion")
                        {
                           foreach(XmlNode myChildAssertion in myChildRespose.ChildNodes)
                            {
                                if(myChildAssertion.Name== "saml:AttributeStatement")
                                {
                                    foreach (XmlNode myNode in myChildAssertion.ChildNodes)
                                    {
                                        if (myNode.Attributes != null)
                                        {
                                            foreach (XmlAttribute myAttribute in myNode.Attributes)
                                            {
                                                if (myAttribute.Value == "email")
                                                {
                                                    foreach (XmlNode myChildNode in myNode.ChildNodes)
                                                    {
                                                        email = myChildNode.InnerText.Replace("\n", "").Trim();
                                                        if (email != string.Empty)
                                                            goto Auth;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    /*XmlElement myAttributeStatement = ((XmlElement)((XmlElement)samlResponseElement.ChildNodes.Item(6)).ChildNodes.Item(10));
                    foreach (XmlNode myNode in myAttributeStatement.ChildNodes)
                    {
                        if (myNode.Attributes != null)
                        {
                            foreach (XmlAttribute myAttribute in myNode.Attributes)
                            {
                                if (myAttribute.Value == "email")
                                {
                                    foreach (XmlNode myChildNode in myNode.ChildNodes)
                                    {
                                        email = myChildNode.InnerText.Replace("\n", "").Trim();
                                        if (email != string.Empty)
                                            goto Auth;
                                    }
                                }
                            }
                        }
                    }*/


                    Auth:
                    if (email != string.Empty)
                    {
                        string myFailureText = string.Empty;
                        var manager = Context.GetOwinContext().GetUserManager<ApplicationUserManager>();
                        var signinManager = Context.GetOwinContext().GetUserManager<ApplicationSignInManager>();
                        var user = manager.FindByEmail(email);
                        if (user!=null)
                        signinManager.SignIn(user, true, false);

                        string mySignIn = new LoginManager().ManageLogin(email, "", out myFailureText);
                        switch (mySignIn)
                        {
                            case "GetProfiloFO":
                                IdentityHelper.RedirectToReturnUrl(UrlHelper.GetProfiloFO, Response);
                                break;
                            case "GetDefaultFO":
                                IdentityHelper.RedirectToReturnUrl(UrlHelper.GetDefaultFO, Response);
                                break;
                            case "GetEmailConfirmation":
                                MySession.Current.Ente = null;
                                Context.GetOwinContext().Authentication.SignOut(DefaultAuthenticationTypes.ApplicationCookie);
                                IdentityHelper.RedirectToReturnUrl(UrlHelper.GetEmailConfirmation, Response);
                                break;
                            case "Errore":
                                FailureText.Text = myFailureText;
                                ErrorMessage.Visible = true;
                                break;
                            case "GetSelDelegante":
                                IdentityHelper.RedirectToReturnUrl(UrlHelper.GetSelDelegante, Response);
                                break;
                            default:
                                break;
                        }
                    }
                }
                else
                {
                    FailureText.Text = "Email obbligatoria per l'accesso.";
                    ErrorMessage.Visible = true;
                }
            }
            catch (Exception ex)
            {
                Log.Debug("OPENgovSPORTELLO.POST.Page_Load::errore::", ex);
            }
        }
    }
    /// <remarks/>
    [Serializable()]
    [System.ComponentModel.DesignerCategory("code")]
    [XmlType(AnonymousType = true, Namespace = "urn:oasis:names:tc:SAML:2.0:assertion")]
    [XmlRoot(Namespace = "urn:oasis:names:tc:SAML:2.0:assertion", IsNullable = false)]
    public partial class AttributeStatement
    {

        private AttributeStatementAttribute[] attributeField;

        /// <remarks/>
        [XmlElement("Attribute")]
        public AttributeStatementAttribute[] Attribute
        {
            get
            {
                return this.attributeField;
            }
            set
            {
                this.attributeField = value;
            }
        }
    }

    /// <remarks/>
    [Serializable()]
    [System.ComponentModel.DesignerCategory("code")]
    [XmlType(AnonymousType = true, Namespace = "urn:oasis:names:tc:SAML:2.0:assertion")]
    public partial class AttributeStatementAttribute
    {
        private string attributeValueField;

        private string nameField;

        private string nameFormatField;

        /// <remarks/>
        public string AttributeValue
        {
            get
            {
                return this.attributeValueField;
            }
            set
            {
                this.attributeValueField = value;
            }
        }

        /// <remarks/>
        [XmlAttribute()]
        public string Name
        {
            get
            {
                return this.nameField;
            }
            set
            {
                this.nameField = value;
            }
        }

        /// <remarks/>
        [XmlAttribute()]
        public string NameFormat
        {
            get
            {
                return this.nameFormatField;
            }
            set
            {
                this.nameFormatField = value;
            }
        }
    }
}